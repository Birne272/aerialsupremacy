function output = realtermfscanf(input, terminator, timeOut, outputFormat, maxCharacters)
% REALTERMSCANF reads out a "line" up to the terminator specified.  Input
% can be the Realterm object, the capture file ID, or the capture file
% name.  Terminator must be a string, and timeOut must be a valid number.
% The outputFormat (see sscanf) and maximum characters can also be supplied
% if required.  The default timeout is 5 seconds if not supplied.  The
% default outputFormat is effectively %s.

% checks the number of input arguments
error(nargchk(2, 5, nargin))

% first stage error checking

% decides what to do based on the input
if isnumeric(input)
    % check it
    if ~any(input == fopen('all'))
        % errors
        error('Invalid file ID to read from.')
    end
    
    % define the fid
    fid = input;
    
elseif ischar(input)
    % use the filename
    if ~exist(input, 'file')
        % complain
        error('File does not exist.')
    end
    
    % get the file id
    fid = getfid(input);
        
elseif isa(input, 'COM.realterm_realtermintf') || ~isscalar(input)
    % gives a warning if capture is not currently on
    if any(strfind(object.Capture, 'off'))
        % capture must be started
        warning('realtermfread:captureIsOff', 'Data capture is currently not on.')
    end
    
    % fetch the fid
    fid = realtermfid(input);
    
else
    % invalid
    error('Input must be a file ID, filename, or a Realterm object.')
end

% terminator
if nargin >= 2
    % check it
    if ~ischar(terminator)
        % terminator must be a string or a number
        error('Terminator must be a string.')
    end
    
else
    % set it to empty
    terminator = '';
end

% error handling
if nargin >= 3
    % checks its ok
    if ~isnumeric(timeOut) || ~isscalar(timeOut) || ~isreal(timeOut) || isinf(timeOut) || isnan(timeOut) || timeOut <= 0
        % the timeout must be greater than 0
        error('Timeout must be egreater than 0.')
    end
    
else
    % otherwise use the default
    timeOut = 5;
end

% check the outputFormat
if nargin >= 4 && (~ischar(outputFormat) || size(outputFormat, 1) ~= 1)
    % error
    error('Output format must be a valid string.')
end

% more
if nargin >= 5
    % checks the max characters
    if ~isscalar(maxCharacters) || ~isreal(maxCharacters) || isnan(maxCharacters) || ~maxCharacters
        % the max characters must be a number bigger than 0 (Inf is allowed)
        error('Max characters must be a number bigger than 0.')
    end
    
else
    % use the default
    maxCharacters = Inf;
end

% specify a start time (in seconds)
startTime = now * 24 * 60 * 60;

% defines the precision (nothing to do with the format - an fread issue) -
% fread is used because you can't use timeout otherwise
precision = '*char';

% initialses output
output = '';

% keeps on going until it matches or hits the end of the file, or
% the timeout is breached (doesn't use for loop since you can't do
% 1:Inf as a counter)
while numel(output) < maxCharacters
    % defines the logical responses
    reachedTerminator = numel(output) >= numel(terminator) && all(output(end - numel(terminator) + 1:end) == terminator);
    timedOut = (now * 24 * 60 * 60 - startTime) > timeOut;

    % if any of those are reached, then leave the loop
    if reachedTerminator || timedOut
        % leave
        break

    else
        % reads another byte out
        output = [output, fread(fid, 1, precision)];
    end
end

% formats it if necessary
if nargin >= 5
    % formats
    output = sscanf(output, outputFormat);
end