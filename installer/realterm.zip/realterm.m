function object = realterm(serialPort, varargin)
% REALTERM works similar to serial objects, although currently only
% the basic properties (baud rate, flow control etc etc) are supported.

% checks the number of arguments
error(nargchk(1, Inf, nargin))

% checks the port
if ~ischar(serialPort)
    % errors
    error('Port must be a valid string, e.g. ''COM1''.')

elseif ~ispv(varargin{:})
    % error
    error('Subsequent arguments must be valid property/value pairs.')
end
                
% converts the input arguments into a structure (easier for checking)
varargin = reshape(varargin, 2, []);

% finds the index of things
comPortIndex = strcmp('Port', varargin(1, :));

% removes the COM port from there (it'll be done later, and differently)s
if any(comPortIndex)
    % remove it
    varargin(:, comPortIndex) = [];
end

% finds the rest next (as otherwise the varargin is resized and this breaks
% things)
baudIndex = strcmp('BaudRate', varargin(1, :));
flowControlIndex = strcmp('FlowControl', varargin(1, :));
parityIndex = strcmp('Parity', varargin(1, :));

% baud rate first
if any(baudIndex)
    % rename the field
    varargin{1, baudIndex} = 'baud';
end

% parity next
if any(parityIndex)
    % rename the field, and also convert the value into uppercase
    varargin(:, parityIndex) = {'parity';...
                                upper(varargin{2, parityIndex})};
end

% more complicated for flow control
if any(flowControlIndex)
    % defines the flow control
    switch varargin{2, flowControlIndex}
        case 'none'
            flowControl = 0;

        case 'hardware'
            % this is for standard DTR/DSR control - for RTS/CTS you use code 2
            flowControl = 1;

        case 'software'
            % this appears to be currently unavailable via the ActiveX
            % interface
            error('Cannot currently implement software flow control using Realterm.')

        otherwise
            % use the Realterm standard
            flowControl = varargin{2, flowControlIndex};
    end
    
    % store it
    varargin{2, flowControlIndex} = flowControl;
end

% sets up the server
object = actxserver('realterm.realtermintf');

% sets it up as per the serial properties already described (to
% prevent unecessary duplication of code), plus some more to hide it away
set(object, varargin{:},... 
            'Caption', 'MATLAB RealTerm Server',...
            'WindowState', 'wsMinimized',...
            'CaptureDirect', 1,...
            'Visible', 0)

% inexplicably have to assign the port after everything else or it
% doesn't work (it must be the port number, but in char form (strange)
object.Port = serialPort(isstrprop(serialPort, 'digit'));