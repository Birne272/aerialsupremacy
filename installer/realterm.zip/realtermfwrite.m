function realtermfwrite(object, input)
% REALTERMFWRITE sends a command to the serial device via realterm.

% checks the number of input arguments
error(nargchk(2, 2, nargin))

% error handling
if ~isa(object, 'COM.realterm_realtermintf') || ~isscalar(object) || ~object.PortOpen
    % the real term object must be a valid object and connected
    error('The realTermobject is not valid or not connected.')
    
elseif (~isnumeric(input) && ~ischar(input)) || ~isvector(input)
    % the input must be a string
    error('Must send the data as a numeric vector.')
end

% converts the input if it needs to be
if isnumeric(input)
    % converts it
    input = char(input);
end

% depending on the size of the input, and if it contains any 0s - UPDATE -
% this has been deprecated because realterm appears to be modifying the
% last byte in the string if it is larger than 129 (seen for 132 but OK for
% 129) - unknown why! - for robustness, done for larger than 127 (suspected
% its an issue with post-ASCII codes)
if numel(input) == 1 || any(~input) || any(double(input) > 127)
    % sends it a character at a time
    for m = 1:numel(input)
        % sends it
        invoke(object, 'PutChar', input(m))
    end

else
    % send it as a string
	invoke(object, 'PutString', input)
end