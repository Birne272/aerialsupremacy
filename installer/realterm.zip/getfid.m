function fid = getfid(fileName)
% GETFID returns the fid(s) of the file if it is open in MATLAB.  fileName
% can be a string, or a cell array of strings.  If a file is not open, it
% will return an empty value.  If fileName is a cell array, the response
% will be a cell array of fids.

% checks the number of arguments
error(nargchk(1, 1, nargin))

% checks the filename
if ischar(fileName) && ~exist(fileName, 'file')
    % error
    error('File does not exist.')
    
elseif iscellstr(fileName) && any(cellfun(@(x) ~exist(x, 'file'), fileName))
    % error
    error('At least one file does not exist.')
    
elseif ~ischar(fileName) && ~iscellstr(fileName)
    % error
    error('Input must be a string or a cell array of strings of filenames.')
end

% gets all the open files
allFid = fopen('all');

% gets all the filenames
allFiles = arrayfun(@fopen, allFid, 'UniformOutput', false);

% shortcut for scalars
if ischar(fileName)
    % gets the fid    
    fid = allFid(ismember(allFiles, fileName));
    
else
    % "vectorised"
    fid = cellfun(@(x) allFid(ismember(allFiles, x)), fileName, 'UniformOutput', false);
end