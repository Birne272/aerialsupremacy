function realtermfclose(object, fid)
% REALTERMFCLOSE closes communication with the Realterm serial object.
% Object must be a Realtem ActiveX object.  fid can be optionally supplied
% by the user if whatever reason they don't want the fid to be found by
% MATLAB via the fopen('all') method.

% checks the number of input arguments
error(nargchk(1, 2, nargin))

% error handling
if ~isa(object, 'COM.realterm_realtermintf') || ~isscalar(object) || ~object.PortOpen
    % the real term object must be a valid object and connected
    error('The realTermobject is not valid or not connected.')
end

% and the fid
if nargin >= 2
    if ~isnumeric(fid) || ~isscalar(fid) || ~any(fid == fopen('all'))
        % the file ID must be vaild
        error('Invalid capture file ID.')
    end

    % gets the capture file from Realterm (assumes the user has supplied
    % the write fid)
    captureFile = object.CaptureFile;
    
else
    % then fetch the fid 
    [fid, captureFile] = realtermfid(object);
    
    % give a warning if its empty
    if isempty(fid)
        % warn
        warning('realtermfclose:couldNotFindFid', 'Could not locate the file ID for the capture file.')
    end
end

% tries to stop the capture
try
    % tries to stop the capture
    object.StopCapture

    % closes the port
    object.PortOpen = 0;

    % closes the server
    try
        % closes the server
        object.Close

        % deletes the server
        delete(object)

    catch
        % errors
        error('Could not correctly close the ActiveX Real Term server.')
    end
    
    % closes the capture file in MATLAB
    fclose(fid);
    
    % if the file exists, tidy up
    if exist(captureFile, 'file')
        % deletes the capture file
        delete(captureFile)
    end

catch
    % displays a warning
    warning('tharBPRObjDisconnect:ActiveXCloseFailure', 'Could correctly stop the data capture.')
end