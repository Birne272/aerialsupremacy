function output = isrealterm(input)
% ISREALTERM checks if the object is a Realterm activeX object or not.
% Also accepts it in cell array form.

% checks the number of arguments
error(nargchk(1, 1, nargin))

% if it is an object...
if isa(input, 'COM.realterm_realtermintf')
    % then return true
    output = true;
    
elseif iscell(input)
    % unpack (no recursion)
    output = cellfun('isclass', input, 'COM.realterm_realtermintf');
    
else
    % its not a realterm object
    output = false;
end