function uniqueFileName = createuniquefile(fileName)
% CREATEUNIQUEFILE generates a unique filename that does not already exist

% checks the number of arguments
error(nargchk(1, 1, nargin))

% checks the filename
if ~ischar(fileName) || size(fileName, 1) ~= 1
    % filename must be a valid string
    error('Filename must be a valid string.')
end

% tries to split the filename up - it will error if the filename is not
% valid
try
    % splits it up
    [path, name, extension] = fileparts(fileName);
    
    % starts a ticker
    ticker = 1;
    
    % generates a new filename
    while exist(genFile(path, name, ticker, extension), 'file')
        % increment the ticker
        ticker = ticker + 1;
    end
    
    % return that file
    uniqueFileName = genFile(path, name, ticker, extension);
    
catch
    % errors
    error('Could not deconstruct filename - not valid.')
end


function filename = genFile(path, name, ticker, extension)
% GENFILE generates a filename from the supplied componenents

% written as a separate callback to avoid code duplication
filename = [path, filesep, name, '_', num2str(ticker), extension];