function realtermfprintf(object, input, terminator)
% REALTERMFPRINTF sends a command to the serial device via realterm.  Note
% that there is no support for 'mode' since Realterm is by definition
% asynchronous.

% checks the number of input arguments
error(nargchk(2, 3, nargin))

% error handling
if ~isa(object, 'COM.realterm_realtermintf') || ~isscalar(object)
    % the real term object must be a valid object
    error('The realTermobject is not valid.')
    
elseif ~object.PortOpen
    % realterm must be connected
    error('Realterm is not connected to the serial object.')
    
elseif ~ischar(input) || size(input, 1) ~= 1;
    % the input must be a string
    error('Must send the data as a string.')
    
elseif ~ischar(terminator) || size(terminator, 1) ~= 1
    % if supplied the terminator must be a string
    error('The terminator must be a string.')
end

% currently just runs the fwrite command - not very sophisticated
realtermfwrite(object, [input, terminator])