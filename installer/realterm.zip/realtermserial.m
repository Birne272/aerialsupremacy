function object = realtermserial(serialObject, varargin)
% REALTERMSERIAL generates an ActiveX object from a previously configured serial
% object.  Multiple serial objects are not supported.

% checks the number of arguments
error(nargchk(1, Inf, nargin))

% checks the serial object
if ~isa('serial', serialObject) || ~isscalar(serialObject) || ~isvalid(serialObject) || strcmp(serialObject.Status, 'Open')
    % errors
    error('This only works for valid single CLOSED serial objects.')
    
elseif nargin >= 2 && ~ispv(varargin{:})
    % can add additional properties is provided
    error('Additional properties must be set with valid property/value pairs.')
end

% tries to set up the realTermobject in the structure (deliberately not
% done inside the serial object so that if it errors it is not as much
% of a problem)
try
    % defines the flow control
    switch serialObject.FlowControl
        case 'none'
            flowControl = 0;

        case 'hardware'
            % this is for standard DTR/DSR control - for RTS/CTS you use code 2
            flowControl = 1;

        case 'software'
            % this appears to be currently unavailable via the ActiveX
            % interface
            error('Cannot currently implement software flow control using Realterm.')

        otherwise
            % unknown flow control type
            error('Unknown flow control type.')
    end
    
    % sets up the server
    object = actxserver('realterm.realtermintf');

    % sets it up as per the serial properties already described (to
    % prevent unecessary duplication of code)
    set(object, 'baud', serialObject.BaudRate,...
                'StopBits', serialObject.StopBits,...
                'DataBits', serialObject.DataBits,...
                'Parity', upper(serialObject.Parity),...
                'FlowControl', flowControl,...
                'Caption', 'MATLAB RealTerm Server',...
                'WindowState', 'wsMinimized',...
                'CaptureDirect', 1,...
                'Visible', 0)

    % inexplicably have to assign the port after everything else or it
    % doesn't work
    object.Port = serialObject.Port(isstrprop(serialObject.Port, 'digit'));
    
    % if some more properties were provided, try to apply those (it will
    % error if the properties are invalid)
    if nargin >= 2
        % applies them
        set(object, varargin{:})
    end

catch
    % if the object exists and its still a valid object, close the object
    if exist('object', 'var') && isa(object, 'COM.realterm_realtermintf')
        % closes it
        object.Close

        % deletes it
        delete(object)
    end
    
    % rethrows the error so we know what went wrong
    rethrow(lasterror)
end