function [fid, captureFileName] = realtermfopen(object, captureFileName)
% REALTERMFOPEN connects like fopen does with serial objects (more like
% when ordinary files are opened really).  The file ID and the capture file
% are returned, but only the fid is required for reading out from the
% device.  A unique filename is generated if the capture filename is not
% specified.

% checks the number of input arguments
error(nargchk(1, 2, nargin))

% error handling
if ~isa(object, 'COM.realterm_realtermintf') || ~isscalar(object) || ~object.PortOpen
    % the real term object must be a valid object and connected
    error('The realTermobject is not valid or not connected.')
    
elseif nargin >= 2 && (~ischar(captureFileName) || size(captureFileName, 1) ~= 1)
    % errors
    error('The capture filename must be a valid string.')
end

% specify a default if necessary
if nargin >= 2
    % if the caption is empty, generate a name, otherwise use the caption as
    % the basis for the filename
    if ~isempty(object.Caption)
        % use the caption, removing any spaces
        filename = object.Caption(~isspace(object.Caption));

    else
        % use a generic temporary filename
        filename = 'temp';
    end

    % generates a meaningful unique filename in the same directory as this
    % function
    captureFileName = createuniquefile([fileparts(mfilename('fullpath')), filesep, filename, '.dat']);
    
elseif exist('file', captureFileName)
    % give a warning if it already exists
    warning('realtermfopen:captureFileAlreadyExists', 'Supplied capture file name already exists.')
end

% connects
object.PortOpen = 1;

% check that it opened OK
if ~object.PortOpen
    % errors
    error('Did not connect.')
end

% passes the filename to realterm
object.CaptureFile = captureFileName;

% start capture
object.StartCapture

% try-catched for tidiness
try
    % open the file in MATLAB (read-only)
    fid = fopen(captureFileName);
    
catch
    % if it didn't work, stop the capture
    object.StopCapture

    % empty the capture file field
    object.CaptureFile = '';
    
    % close it
    fclose(fid);

    % delete the file if it exists
    if exist(captureFileName, 'file')
        % delete it
        delete(captureFileName)
    end

    % rethrow the error
    rethrow(lasterror)
end