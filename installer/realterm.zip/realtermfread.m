function output = realtermfread(input, timeOut, maxCharacters, precision)
% REALTERMFREAD used similarly to fread with serial objects
% (only limited to one output argument at present).  The first input can be
% the Realterm object, the file ID for the capture file, or the filename
% itself.  If only one argument is supplied, then everything will be read
% out (no timeout).  If timeOut is empty, then the default timeout of 5
% seconds will be used. Precision is as in fread, and the default is
% 'uchar'.

% checks the number of arguments
error(nargchk(1, 4, nargin))

% first stage error checking

% decides what to do based on the input
if isnumeric(input)
    % check it
    if ~any(input == fopen('all'))
        % errors
        error('Invalid file ID to read from.')
    end
    
    % define the fid
    fid = input;
    
elseif ischar(input)
    % use the filename
    if ~exist(input, 'file')
        % complain
        error('File does not exist.')
    end
    
    % get the file id
    fid = getfid(input);
        
elseif isa(input, 'COM.realterm_realtermintf') || ~isscalar(input)
    % gives a warning if capture is not currently on
    if any(strfind(object.Capture, 'off'))
        % capture must be started
        warning('realtermfread:captureIsOff', 'Data capture is currently not on.')
    end
    
    % fetch the fid
    fid = realtermfid(input);
    
else
    % invalid
    error('Input must be a file ID, filename, or a Realterm object.')
end

% error handling
if nargin >= 2
    % checks its ok
    if ~isnumeric(timeOut) || ~isscalar(timeOut) || ~isreal(timeOut) || isinf(timeOut) || isnan(timeOut) || timeOut <= 0
        % the timeout must be greater than 0
        error('Timeout must be egreater than 0.')
    end
    
else
    % otherwise use the default
    timeOut = 5;
end

% more
if nargin >= 3
    % checks the max characters
    if ~isscalar(maxCharacters) || ~isreal(maxCharacters) || isnan(maxCharacters) || ~maxCharacters
        % the max characters must be a number bigger than 0 (Inf is allowed)
        error('Max characters must be a number bigger than 0.')
    end
    
else
    % use the default
    maxCharacters = Inf;
end

% deals with the precision (can't yet easily check for this)
if nargin >= 4
    % checks the precision
    if ~ischar(precision) || size(precision, 1) ~= 1
        % the precision must be a string
        error('The precision must be a string.')
    end

else
    % define the precision
    precision = 'uchar';
end

% specify a start time (in seconds)
startTime = now * 24 * 60 * 60;

% defines an output
output = [];

% loops until it reads the amount requested, or the timeout is reached
while numel(output) < maxCharacters && (now * 24 * 60 * 60 - startTime) < timeOut
    % tries to read it out
    output = vertcat(output, fread(fid, maxCharacters, precision));
end

% if at the end it was a timeout and the max characters was not reached...
if (now - startTime) > timeOut && ~isinf(maxCharacters) && numel(output) < maxCharacters
    % display a warning
    warning('realtermfread:timeOut', 'Communication timed out.')
end