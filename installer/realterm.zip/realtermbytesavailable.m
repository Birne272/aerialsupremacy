function bytesAvailable = realtermbytesavailable(input)
% REALTERMBYTESAVAILABLE gives the bytes available for a Realterm object
% bytesAvailable = realtermbytesavailable(fid) reads the bytes
% available for Realterm objects created using realterm.  fid can be the
% fid of the capture file, the capture filename, or the Realterm object
% itself.

% checks the number of arguments
error(nargchk(1, 1, nargin))

% decides what to do based on the input
if isnumeric(input)
    % check it
    if ~any(input == fopen('all'))
        % errors
        error('Invalid file ID to read from.')
    end
    
    % define the fid
    fid = input;
    
    % gets the filename
    captureFile = fopen(fid);
    
elseif ischar(input)
    % use the filename
    if ~exist(input, 'file')
        % complain
        error('File does not exist.')
    end
    
    % get the file id
    fid = getfid(input);
    
    % saves the filename
    captureFile = fileName;
        
elseif isa(input, 'COM.realterm_realtermintf') || ~isscalar(input)
    % fetch the fid
    [fid, captureFile] = realtermfid(input);
    
else
    % invalid
    error('Input must be a file ID, filename or a Realterm object.')
end

% get the current position of the file (with respect to the
% beginning of the file)
filePosition = ftell(fid);

% to avoid any issues with interfering with the file position, the
% file is reopened again
searchFileID = fopen(captureFile);

% if it didn't work...
if ~searchFileID
    % we'll use the captureFileID instead
    searchFileID = fid;
end

% seek to the end, discarding any data
fread(searchFileID);

% calculates the bytes left
bytesAvailable = ftell(searchFileID) - filePosition;

% if we're using the same fileID...
if searchFileID == fid
    % seek back to the original position
    fseek(fid, filePosition, 'bof')

else
    % close the file
    result = fclose(searchFileID);

    % check it closed properly
    if result
        % give a warning
        warning('serialBytesAvailable:didNotCloseFile', 'Did not close the temporary file session.')
    end
end