function response = ispv(varargin)
% ISPV checks if all the arguments supplied conform to valid property-value
% syntax.

% checks the number of arguments
error(nargchk(0, Inf, nargin))

% shortcut for if there are no arguments
if ~nargin
    % not valid
    response = false;

else
    % defines the indices
    indices = 1:nargin;

    % checks that there is an even number of arguments, and that the odd
    % arguments (the field names) are all strings
    response = ~rem(nargin, 2) && iscellstr(varargin(indices(isodd(indices))));
end