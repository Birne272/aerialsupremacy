function [fid, captureFile] = realtermfid(object)
% REALTERMFID recovers the capture file and fid from Realterm objects.

% checks the number of arguments
error(nargchk(1, 1, nargin))

% and the realterm object (does not check if it is connected or not)
if ~isa(object, 'COM.realterm_realtermintf') || ~isscalar(object)
    % errors
    error('Must use a valid Realterm activeX object.')
end

% fetches the capture file
captureFile = object.CaptureFile;

% and the fid
fid = getfid(captureFile);

% only if its open, also check if it is open and really is capturing
if ~isempty(fid) && object.PortOpen && ~object.Capture
    % display a warning
    warning('realtermfid:noCapture', 'Realterm is connected but not capturing.')
end